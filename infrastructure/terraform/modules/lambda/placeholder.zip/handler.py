def handler(event, context):
    # Placeholder — replace with the OCR/classification worker.
    print(f"received {len(event.get('Records', []))} message(s)")
    return {"ok": True}
